#ifndef __book
#define __book

#include<string.h>

class book
{
private:
book books[1000];
int n=0;
int bookid;                ///////////////////////////
	char bookname[60];         ///////////////////////////
	char authorname[40];       ///////////////////////////
	char bookcategory[20];     ///Members of structure/// 
	char bookpubcom[30];       ///////////////////////////
	char bookpubmonth[10];     ///////////////////////////
	int bookpubyear;           ///////////////////////////

public:
void display();
void add();
void search();
void sort();
void del();
void modify();
void gotoxy(short x,short y);

}