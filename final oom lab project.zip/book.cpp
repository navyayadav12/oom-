#include<bits/stdc++.h>
#include<string.h>
#include "book.h"

using namespace std;
book books[1000];
int n=0;


void book:: display(void)
	{
		system("cls");
		cout<< "In display function\n";
		cout<<"__________"<<"__________________________________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<endl;
		cout<<setw(10)<<"\"Book ID\""<<setw(50)<<"\"Book Name\""<<setw(30)<<"\"Author Name\""<<setw(30)<<"\"Category\""<<setw(30)<<"\"Publication\""<<setw(30)<<"\"Month of Publication\""<<setw(30)<<"\"Year of Publication\""<<endl;
		cout<<"__________"<<"__________________________________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<endl;
		for(int i=0;i<n;i++)
			{
				cout<<setw(10)<<books[i].bookid<<setw(50)<<books[i].bookname<<setw(30)<<books[i].authorname<<setw(30)<<books[i].bookcategory<<setw(30)<<books[i].bookpubcom<<setw(30)<<books[i].bookpubmonth<<setw(30)<<books[i].bookpubyear<<endl;
				cout<<"__________"<<"__________________________________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<endl;
			}
			cout<<"Press enter to goto main manu.....";
			getch();
			
	}
	

//////////////////////////////////////
///////////////////Add///////////////
/////////////////////////////////////
void book::add(void)
	{
		char ch;char id1[6],year[4];
		do
		{
			system("cls");
			cout<<endl;
			cout<< "In ADD function\n";
			cout<<"Enter Book Name: ";    
			gets(books[n].bookname);
			//cin.getline(emp[n].name,40);
			//cin.ignore(40,'\n');
			cout<<"Enter Book ID: ";
			gets(id1);
			books[n].bookid=atoi(id1);
			//cin.ignore();
			cout<<"Enter Author Name: ";
			gets(books[n].authorname);
			cout<<"Enter Book Category: ";
			gets(books[n].bookcategory);
			cout<<"Enter Publication Company Name: ";
			gets(books[n].bookpubcom);
			cout<<"Enter Publication Month: ";
			gets(books[n].bookpubmonth);
			cout<<"Enter Publication Year: ";
			gets(year);
			books[n].bookpubyear=atoi(year);
			n++;
		cout<<"Do you want to add more books? [y/n]";
		ch=getch();
		}
		while(ch!='n'&& ch!='N');
	}

//////////Search////////////////////
void book::search(void)
	{
		system("cls");
	   
	  

       char name[60];
		int loc,found=0;
		system("cls");
		cout<<endl;
		cout<<"Searching by name of book\n";
		cout<<"Enter the name of book you want to search: ";
		gets(name);
		for(int i = 0;i<n;i++)
		{
			if(strcmp(books[i].bookname,name)==0)
			{
				loc=i;
				found = 1;
				cout<< "Record Found!"<<endl;
				cout<<"__________"<<"__________________________________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<endl;
				cout<<setw(10)<<"\"Book ID\""<<setw(50)<<"\"Book Name\""<<setw(30)<<"\"Author Name\""<<setw(30)<<"\"Category\""<<setw(30)<<"\"Publication\""<<setw(30)<<"\"Month of Publication\""<<setw(30)<<"\"Year of Publication\""<<endl;
				cout<<"__________"<<"__________________________________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<endl;
				cout<<setw(10)<<books[loc].bookid<<setw(50)<<books[loc].bookname<<setw(30)<<books[loc].authorname<<setw(30)<<books[loc].bookcategory<<setw(30)<<books[loc].bookpubcom<<setw(30)<<books[loc].bookpubmonth<<setw(30)<<books[loc].bookpubyear<<endl;
				cout<<"__________"<<"__________________________________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<endl;	
			}
		}
		if(found == 0)
			cout<<"Record not Found"<<endl;
		cout<<"Press enter to goto main manu.....";
		getch();

	}
	

	


///////Sort in Ascending Order///////

void book::sort(void)
{
	system("cls");
	   
	   int i,j;
		book temp;
		system("cls");
		cout<<endl;
		cout<< "Sorting in Ascending Order by Name\n";
		for(i=0;i<n;i++)
		{
			for(j=0;j<n-i-1;j++)
			{
				if(strcmp(books[j].bookname,books[j+1].bookname)>0)
				{
					temp = books[j];
					books[j]=books[j+1];
					books[j+1]=temp;	
				}
			}
		}
		display();
}


void book::del(void)
	{
		system("cls");

        char name[60];
		int loc,found=0;
		system("cls");
		cout<<endl;
		cout<<"Deleting by name of book\n";
		cout<<"Enter the name of book you want to delete: ";
		gets(name);
		for(int i = 0;i<n;i++)
		{
			if(strcmp(books[i].bookname,name)==0)
			{
				loc=i;
				found = 1;
				for (i = loc;i<n-1;i++)
				{
					books[i]=books[i+1];
				}
				n--;
			}
		}
		if(found == 0)
			cout<<"Record not Found"<<endl;
		cout<<"Press enter to goto main manu.....";
		getch();
	   
	   
	}


void book::modify(void)
	{
		system("cls");

        char name[60];
		int loc,found=0;
		system("cls");
		cout<<endl;
		cout<<"Modifying by name of book\n";
		cout<<"Enter the name of book you want to modify: ";
		gets(name);
		for(int i = 0;i<n;i++)
		{
			if(strcmp(books[i].bookname,name)==0)
			{
				loc=i;
				found = 1;
				char ch;char id1[6],year[4];
				system("cls");
				cout<<"__________"<<"__________________________________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<endl;
				cout<<setw(10)<<"\"Book ID\""<<setw(50)<<"\"Book Name\""<<setw(30)<<"\"Author Name\""<<setw(30)<<"\"Category\""<<setw(30)<<"\"Publication\""<<setw(30)<<"\"Month of Publication\""<<setw(30)<<"\"Year of Publication\""<<endl;
				cout<<"__________"<<"__________________________________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<endl;
				cout<<setw(10)<<books[loc].bookid<<setw(50)<<books[loc].bookname<<setw(30)<<books[loc].authorname<<setw(30)<<books[loc].bookcategory<<setw(30)<<books[loc].bookpubcom<<setw(30)<<books[loc].bookpubmonth<<setw(30)<<books[loc].bookpubyear<<endl;
				cout<<"__________"<<"__________________________________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<"______________________________"<<endl;	
				cout<<endl;
				cout<< "In Modify function\n";
				cout<<"Enter new Book Name: ";    
				gets(books[loc].bookname);
				//cin.getline(emp[n].name,40);
				//cin.ignore(40,'\n');
				cout<<"MODIFIED!"<<endl;
		}
		if(found == 0)
			cout<<"Record not Found"<<endl;
		cout<<"Press enter to goto main manu.....";
		getch();
		}
	   
	  
	}


void book::gotoxy(short x, short y) 
{
COORD pos = {x, y};
SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
}
//////////////////////////////////////////
