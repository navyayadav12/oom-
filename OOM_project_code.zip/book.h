#ifndef _book
#define _book

namespace x{

    class book       
{

    public:
	int bookid;                
	char bookname[60];         
	char authorname[40];       
	char bookcategory[20];     
	char bookpubcom[30];       
	char bookpubmonth[10];     
	int bookpubyear;           

    

};
   
}

#endif 