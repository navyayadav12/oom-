#include<iostream>   
#include<iomanip>    
#include<fstream>    
#include<conio.h>    
#include<string.h>   
#include<stdio.h>    
#include <cstdlib>   
#include <windows.h> 
#include "book.h"

using namespace std;
using namespace x;

void gotoxy(short , short ); 
void display(); //display function
void add();     //add function
void search();  //search function
void sort();    //sort function
void del();     //delete function
void modify();  //modify function

//book books[1000];          
  //  int n=0;                   
    

int main()
{
	char ch1;
	while (1)
    {
		system("cls");
	   
		cout << setw( 25 ) << "-------------" << endl

          << setw( 25 ) << "| MAIN MENU |" << endl

          << setw( 25 ) << "-------------" << endl << endl

          << setw( 52 )

          << "Please choose one of the options below: "

          << endl << setw( 71 )

          << "--------------------------------------------------------------"

          << endl << endl

 

          << setw( 25 ) << "( A ) Add Book" << endl << endl

          << setw( 31 ) << "( O ) Sort all Books" << endl << endl

          << setw( 33 ) << "( S ) Search all Books" << endl << endl

          << setw( 33 ) << "( D ) Diplay all Books" << endl << endl

          << setw( 30 ) << "( T ) Delete a Book" << endl << endl

          << setw( 40 ) << "( M ) Update Book Information" << endl << endl
         
		  << setw( 21 ) << "( Q ) Quit" << endl << endl
		  <<setw( 32 ) << "Enter Option      [ ]" << endl << endl;
			gotoxy(30,21);
	     
		switch(getche())
		{
			case 'a':
		 	case 'A':add();break;
         
			case 'd':
		 	case 'D': display();break;
         
		 	case 'S':
		 	case 's':search();break;
         
		 	case 't':
		 	case 'T':del();break;
		 
		 	case 'O':
		 	case 'o':sort();break;
         
		 	case 'm':
		 	case 'M':modify();break;
		 
		 	case 'q':
		 	case 'Q':exit(0);break;
         
		 	default:
			puts("\n\n \t\tSelect only from the given menu.....\n \t\tpress enter to to go to main menu......");
			getch();
       } //end switch
     }//end while
    
	getch();
 }//end main